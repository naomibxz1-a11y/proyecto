import { TransactionBlock } from "@mysten/sui";
import { PACKAGE_ID, MODULE_NAME, FUNCTION_ADD } from "../functionsConfig";

export async function registerProduct(wallet, name, quantity, price) {
    const tx = new TransactionBlock();

    tx.moveCall({
        target: `${PACKAGE_ID}::${MODULE_NAME}::${FUNCTION_ADD}`,
        arguments: [
            tx.pure.string(name),
            tx.pure.u64(quantity),
            tx.pure.u64(price)
        ]
    });

    const result = await wallet.signAndExecuteTransactionBlock({
        transactionBlock: tx
    });

    return result;
}
