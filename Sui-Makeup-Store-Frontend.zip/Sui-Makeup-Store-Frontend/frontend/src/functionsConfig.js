// Si tienes tu propio contrato reemplaza PACKAGE_ID y MODULE_NAME
export const PACKAGE_ID = "0xba2cfa1d3d9814d2a90bc6d199a6d65ac1ce03692e9a7e1f89f816c67d2e4b8e";
export const MODULE_NAME = "makeup_store";

export const FUNCTIONS = {
  createStore: "create_store",
  addProduct: "add_product",
  // si tienes una función para listar, agrégala; aquí usaremos solo transacciones
};
