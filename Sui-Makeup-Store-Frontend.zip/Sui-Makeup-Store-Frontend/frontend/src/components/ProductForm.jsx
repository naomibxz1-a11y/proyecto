import React, { useState } from "react";
import { PACKAGE_ID, MODULE_NAME, FUNCTIONS } from "../functionsConfig";

/*
  Esta versión usa window.suiWallet.request para crear y enviar
  una moveCall simple que funcionará con muchas wallets Sui.
  Si tu contrato requiere objetos adicionales, ajusta los argumentos.
*/

export default function ProductForm({ onTxResult }) {
  const [storeId, setStoreId] = useState("");
  const [name, setName] = useState("");
  const [brand, setBrand] = useState("");
  const [price, setPrice] = useState("");
  const [qty, setQty] = useState("");

  const createStore = async () => {
    if (!window.suiWallet) return alert("Instala Sui Wallet");
    try {
      const tx = {
        kind: "moveCall",
        data: {
          packageObjectId: PACKAGE_ID,
          module: MODULE_NAME,
          function: FUNCTIONS.createStore,
          typeArguments: [],
          arguments: [],
          gasBudget: 100000,
        },
      };
      const res = await window.suiWallet.request({
        method: "sui_signAndExecuteTransaction",
        params: { transaction: tx },
      });
      onTxResult && onTxResult(res);
      alert("Tienda creada. Revisa la consola para ver el resultado y copia el objectId como storeId.");
      console.log("createStore res:", res);
    } catch (e) {
      console.error(e);
      alert("Error creando tienda: " + (e.message || e));
    }
  };

  const addProduct = async (e) => {
    e.preventDefault();
    if (!window.suiWallet) return alert("Instala Sui Wallet");
    if (!storeId) return alert("Ingresa el ID de la tienda (storeId) antes de registrar productos.");
    try {
      const tx = {
        kind: "moveCall",
        data: {
          packageObjectId: PACKAGE_ID,
          module: MODULE_NAME,
          function: FUNCTIONS.addProduct,
          typeArguments: [],
          // argumentos: asume [store_object_id, name:string, brand:string, price:u64, qty:u64]
          arguments: [storeId, name, brand, String(Number(price)), String(Number(qty))],
          gasBudget: 100000,
        },
      };
      const res = await window.suiWallet.request({
        method: "sui_signAndExecuteTransaction",
        params: { transaction: tx },
      });
      onTxResult && onTxResult(res);
      alert("Producto enviado a la blockchain. Revisa la consola.");
      console.log("addProduct res:", res);
    } catch (err) {
      console.error(err);
      alert("Error registrando producto: " + (err.message || err));
    }
  };

  return (
    <div className="form-box">
      <h2>Registrar producto</h2>

      <label>ID de tienda (storeId)</label>
      <input placeholder="0x..." value={storeId} onChange={(e) => setStoreId(e.target.value)} />

      <label>Nombre</label>
      <input placeholder="Ej: Lipstick Rosa" value={name} onChange={(e) => setName(e.target.value)} />

      <label>Marca</label>
      <input placeholder="Marca" value={brand} onChange={(e) => setBrand(e.target.value)} />

      <label>Precio (SUI tokens o unidades)</label>
      <input type="number" placeholder="100" value={price} onChange={(e) => setPrice(e.target.value)} />

      <label>Cantidad</label>
      <input type="number" placeholder="10" value={qty} onChange={(e) => setQty(e.target.value)} />

      <button onClick={addProduct}>Registrar producto</button>

      <hr />

      <button onClick={createStore} className="create-store-btn">Crear nueva tienda (store)</button>
    </div>
  );
}

