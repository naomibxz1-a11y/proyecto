import React, { useState } from "react";

export default function WalletConnect({ onConnected }) {
  const [address, setAddress] = useState(null);

  const connect = async () => {
    try {
      if (!window.suiWallet) throw new Error("Instala Sui Wallet o extensión compatible");
      await window.suiWallet.requestPermissions();
      const accounts = await window.suiWallet.getAccounts();
      const acc = accounts?.[0]?.address || null;
      setAddress(acc);
      if (onConnected) onConnected(acc);
    } catch (e) {
      alert("No se pudo conectar la wallet: " + (e.message || e));
    }
  };

  return (
    <div className="wallet-box">
      <button onClick={connect} className="connect-btn">
        {address ? "Wallet conectada" : "Conectar Wallet"}
      </button>
      {address && <div className="wallet-address">Dirección: <code>{address}</code></div>}
    </div>
  );
}
