import React, { useState } from "react";
import WalletConnect from "./components/WalletConnect";
import ProductForm from "./components/ProductForm";

export default function App() {
  const [walletAddress, setWalletAddress] = useState(null);
  const [txLog, setTxLog] = useState(null);

  return (
    <div className="container">
      <header className="hero">
        <img src="/logo.png" alt="logo" style={{ width: 64, height: 64, borderRadius: 8 }} />
        <div>
          <h1>SUI MAKEUP STORE 💄</h1>
          <p className="subtitle">Registra productos de maquillaje y guarda las transacciones en Sui Testnet</p>
        </div>
      </header>

      <WalletConnect onConnected={(addr) => setWalletAddress(addr)} />

      <ProductForm onTxResult={(res) => setTxLog(res)} />

      {txLog && (
        <div className="tx-box">
          <h3>Última transacción</h3>
          <pre>{JSON.stringify(txLog, null, 2)}</pre>
        </div>
      )}

      <footer style={{ marginTop: 20, color: "#666" }}>
        <small>Entrega: Sui Makeup Store – Frontend</small>
      </footer>
    </div>
  );
}
